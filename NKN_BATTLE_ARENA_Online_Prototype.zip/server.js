const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const crypto = require("crypto");

const app = express();
app.use(express.static("public"));
app.get("/health", (_, res) => res.json({ ok: true, game: "NKN BATTLE ARENA" }));

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const rooms = new Map();

const randomId = () => crypto.randomBytes(3).toString("hex").toUpperCase();
const send = (ws, data) => {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
};
function roomState(room) {
  return {
    type: "state",
    roomId: room.id,
    status: room.status,
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, x: p.x, z: p.z, yaw: p.yaw,
      hp: p.hp, score: p.score, ready: true
    }))
  };
}
function broadcast(room) {
  const payload = JSON.stringify(roomState(room));
  for (const p of room.players.values()) {
    if (p.ws.readyState === WebSocket.OPEN) p.ws.send(payload);
  }
}
function finish(room, winnerId) {
  room.status = "finished";
  for (const p of room.players.values()) send(p.ws, {
    type: "matchOver", winnerId, winnerName: room.players.get(winnerId)?.name || "Unknown"
  });
  broadcast(room);
}
function cleanRoom(room) {
  if (room.players.size === 0) rooms.delete(room.id);
}

wss.on("connection", ws => {
  ws.id = crypto.randomUUID();
  ws.roomId = null;

  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === "create") {
      let id = randomId();
      while (rooms.has(id)) id = randomId();
      const room = { id, players: new Map(), status: "waiting" };
      rooms.set(id, room);
      joinRoom(ws, room, msg.name);
      return;
    }
    if (msg.type === "join") {
      const id = String(msg.roomId || "").trim().toUpperCase();
      const room = rooms.get(id);
      if (!room) return send(ws, { type: "error", message: "Room not found. Check the Room ID." });
      if (room.players.size >= 2) return send(ws, { type: "error", message: "Room is full." });
      if (room.status !== "waiting") return send(ws, { type: "error", message: "Match already started." });
      joinRoom(ws, room, msg.name);
      return;
    }
    const room = rooms.get(ws.roomId);
    if (!room || !room.players.has(ws.id)) return;
    const player = room.players.get(ws.id);

    if (msg.type === "move" && room.status === "playing") {
      // Server clamps movement to the island bounds.
      player.x = Math.max(-24, Math.min(24, Number(msg.x) || 0));
      player.z = Math.max(-24, Math.min(24, Number(msg.z) || 0));
      player.yaw = Number(msg.yaw) || 0;
      broadcast(room);
    }
    if (msg.type === "tag" && room.status === "playing") {
      // Abstract arcade tag: server checks range and cooldown; no realistic weapon simulation.
      const now = Date.now();
      if (now - player.lastTag < 450) return;
      player.lastTag = now;
      const target = [...room.players.values()].find(p => p.id !== player.id);
      if (!target) return;
      const dx = target.x - player.x, dz = target.z - player.z;
      if (Math.hypot(dx, dz) > 12) return send(ws, { type: "notice", message: "Target is out of range." });
      target.hp = Math.max(0, target.hp - 20);
      if (target.hp <= 0) {
        player.score += 1;
        finish(room, player.id);
      } else {
        broadcast(room);
      }
    }
  });

  ws.on("close", () => {
    const room = rooms.get(ws.roomId);
    if (!room) return;
    room.players.delete(ws.id);
    if (room.players.size === 1) {
      const remaining = [...room.players.values()][0];
      send(remaining.ws, { type: "notice", message: "Opponent disconnected. Waiting for a new player." });
      room.status = "waiting";
      remaining.hp = 100;
    }
    cleanRoom(room);
    if (rooms.has(room.id)) broadcast(room);
  });
});

function joinRoom(ws, room, name) {
  ws.roomId = room.id;
  const player = {
    id: ws.id, ws, name: String(name || "Player").slice(0, 16),
    x: room.players.size === 0 ? -5 : 5, z: 0, yaw: 0,
    hp: 100, score: 0, lastTag: 0
  };
  room.players.set(ws.id, player);
  send(ws, { type: "joined", roomId: room.id, playerId: ws.id });
  if (room.players.size === 2) room.status = "playing";
  broadcast(room);
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`NKN BATTLE ARENA listening on ${PORT}`));
