import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.161.0/build/three.module.js";

const $ = id => document.getElementById(id);
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8bd2e0);
scene.fog = new THREE.Fog(0x8bd2e0, 45, 100);
const camera = new THREE.PerspectiveCamera(65, innerWidth/innerHeight, .1, 200);
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
$("game").appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xffffff,0x56704a,2));
const sun = new THREE.DirectionalLight(0xffffff,2.2); sun.position.set(-20,35,15); sun.castShadow=true; scene.add(sun);

const mat = (color, roughness=.85) => new THREE.MeshStandardMaterial({color,roughness});
const sand = mat(0xd9c58c), grass=mat(0x5b9a55), water=mat(0x279bb6), trunk=mat(0x765035), leaf=mat(0x287c48), wall=mat(0xd6d0bd), roof=mat(0x9a5944);
const island = new THREE.Mesh(new THREE.CylinderGeometry(34,36,2,64), grass); island.position.y=-1; island.receiveShadow=true; scene.add(island);
const shore = new THREE.Mesh(new THREE.CylinderGeometry(36,37,1.5,64), sand); shore.position.y=-1.6; scene.add(shore);
const sea = new THREE.Mesh(new THREE.PlaneGeometry(300,300), water); sea.rotation.x=-Math.PI/2; sea.position.y=-2.5; scene.add(sea);
function box(x,y,z,sx,sy,sz,material){const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;scene.add(m);return m}
for(let i=0;i<9;i++){let a=i*Math.PI*2/9;let x=Math.cos(a)*23,z=Math.sin(a)*23;box(x,1,z,5,4,5,wall);box(x,3.2,z,5.5,.6,5.5,roof)}
for(let i=0;i<28;i++){let a=i*2.399,r=12+(i%5)*3,x=Math.cos(a)*r,z=Math.sin(a)*r;if(Math.hypot(x,z)>27)continue;let t=new THREE.Mesh(new THREE.CylinderGeometry(.25,.4,2.5,7),trunk);t.position.set(x,0,z);t.castShadow=true;scene.add(t);let l=new THREE.Mesh(new THREE.ConeGeometry(1.8,4,7),leaf);l.position.set(x,2.8,z);l.castShadow=true;scene.add(l)}
// Landmark and loot markers
for(const [x,z,c] of [[0,0,0xffc247],[-14,8,0x65d9ff],[13,-10,0x65d9ff]]){let o=new THREE.Mesh(new THREE.CylinderGeometry(.45,.45,.3,16),new THREE.MeshStandardMaterial({color:c,emissive:c,emissiveIntensity:.25}));o.position.set(x,.2,z);scene.add(o)}

function makeAvatar(color){
 const g=new THREE.Group();
 const body=new THREE.Mesh(new THREE.CapsuleGeometry(.48,.9,4,8),mat(color,.55));body.position.y=1.05;body.castShadow=true;g.add(body);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.34,16,12),mat(0xf0c59c));head.position.y=1.9;head.castShadow=true;g.add(head);
 const pack=new THREE.Mesh(new THREE.BoxGeometry(.55,.65,.25),mat(0x28384a));pack.position.set(0,1.1,-.48);g.add(pack);
 const marker=new THREE.Mesh(new THREE.ConeGeometry(.18,.4,8),mat(0xffffff));marker.position.set(0,2.35,0);g.add(marker);
 scene.add(g);return g;
}
const avatars=new Map();
let myId=null,roomId=null,ws=null,joined=false,playing=false,myHp=100;
let myX=-5,myZ=0,yaw=0,moveX=0,moveY=0,remotePlayers=[];
const me=makeAvatar(0x2878e8); me.position.set(myX,0,myZ);
const clock=new THREE.Clock();
function connect(){
 const proto=location.protocol==="https:"?"wss":"ws";
 ws=new WebSocket(`${proto}://${location.host}`);
 ws.onopen=()=>{$("connection").textContent="CONNECTED";$("connection").style.color="#b8ffca"};
 ws.onclose=()=>{$("connection").textContent="DISCONNECTED";toast("Connection lost. Refresh to reconnect.")};
 ws.onerror=()=>toast("Network connection error.");
 ws.onmessage=e=>{const m=JSON.parse(e.data);
  if(m.type==="joined"){myId=m.playerId;roomId=m.roomId;$("lobby").classList.add("hidden");$("hud").classList.remove("hidden");$("roomBadge").textContent="ROOM "+roomId;toast("Room connected. Share this ID.");}
  if(m.type==="state"){remotePlayers=m.players;playing=m.status==="playing";syncPlayers(m.players);$("matchStatus").textContent=playing?"FIGHT!":"WAITING FOR PLAYER 2";const mine=m.players.find(p=>p.id===myId);if(mine){myHp=mine.hp;$("myHp").textContent=myHp;$("myHealth").style.width=myHp+"%";$("myName").textContent=mine.name;}
   const enemy=m.players.find(p=>p.id!==myId);if(enemy){$("enemyName").textContent=enemy.name;$("enemyHp").textContent=enemy.hp;$("enemyHealth").style.width=enemy.hp+"%";}
  }
  if(m.type==="matchOver"){$("result").classList.remove("hidden");$("resultTitle").textContent=m.winnerId===myId?"VICTORY!":"DEFEAT";$("resultText").textContent=m.winnerName+" wins the match.";playing=false;}
  if(m.type==="error"||m.type==="notice")toast(m.message);
 };
}
function syncPlayers(players){
 for(const p of players){if(p.id===myId){me.position.set(p.x,0,p.z);continue}
  if(!avatars.has(p.id))avatars.set(p.id,makeAvatar(0xe34c4c));
  const a=avatars.get(p.id);a.position.set(p.x,0,p.z);a.rotation.y=p.yaw;
 }
 for(const [id,a] of avatars)if(!players.some(p=>p.id===id)){scene.remove(a);avatars.delete(id)}
}
function send(data){if(ws&&ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(data))}
$("createBtn").onclick=()=>{connect();const n=$("playerName").value||"Player";const wait=()=>{if(ws.readyState===WebSocket.OPEN)send({type:"create",name:n});else setTimeout(wait,100)};wait()};
$("joinBtn").onclick=()=>{const id=$("roomInput").value.trim();if(id.length!==6)return toast("Enter a 6-character Room ID.");connect();const n=$("playerName").value||"Player";const wait=()=>{if(ws.readyState===WebSocket.OPEN)send({type:"join",roomId:id,name:n});else setTimeout(wait,100)};wait()};

function toast(s){$("toast").textContent=s;$("toast").style.display="block";clearTimeout(toast.t);toast.t=setTimeout(()=>$("toast").style.display="none",2400)}
const stick=$("stick"),nub=$("nub");let pointer=null;
stick.addEventListener("pointerdown",e=>{pointer=e.pointerId;stick.setPointerCapture(pointer);updateStick(e)});
stick.addEventListener("pointermove",e=>{if(e.pointerId===pointer)updateStick(e)});
stick.addEventListener("pointerup",()=>{pointer=null;moveX=moveY=0;nub.style.transform="translate(0,0)"});
function updateStick(e){const r=stick.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const len=Math.hypot(dx,dy),max=37;if(len>max){dx=dx/len*max;dy=dy/len*max}moveX=dx/max;moveY=dy/max;nub.style.transform=`translate(${dx}px,${dy}px)`}
$("tagBtn").onclick=()=>{if(playing)send({type:"tag"})};
$("jumpBtn").onclick=()=>{if(!playing)return;me.position.y=.8;setTimeout(()=>me.position.y=0,350)};

// Desktop pointer camera + mobile swipe camera rotation
let lastX=null;
renderer.domElement.addEventListener("pointerdown",e=>{lastX=e.clientX});
renderer.domElement.addEventListener("pointermove",e=>{if(lastX!==null){yaw-=(e.clientX-lastX)*.006;lastX=e.clientX}});
renderer.domElement.addEventListener("pointerup",()=>lastX=null);
function animate(){
 requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);
 if(playing){
  const forward=new THREE.Vector3(Math.sin(yaw),0,Math.cos(yaw));
  const right=new THREE.Vector3(forward.z,0,-forward.x);
  const delta=forward.multiplyScalar(-moveY).add(right.multiplyScalar(moveX));
  if(delta.length()>0){delta.normalize().multiplyScalar(7*dt);myX=Math.max(-29,Math.min(29,myX+delta.x));myZ=Math.max(-29,Math.min(29,myZ+delta.z));me.position.set(myX,me.position.y,myZ);me.rotation.y=yaw;send({type:"move",x:myX,z:myZ,yaw});}
 }
 const target=new THREE.Vector3(me.position.x,1.2,me.position.z);
 const camOffset=new THREE.Vector3(Math.sin(yaw)*-7,4,Math.cos(yaw)*-7);
 camera.position.lerp(target.clone().add(camOffset),.12);camera.lookAt(target);
 renderer.render(scene,camera);
}
animate();
addEventListener("resize",()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
