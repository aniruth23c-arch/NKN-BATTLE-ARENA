# NKN BATTLE ARENA — Online 1v1 Prototype

This is a deployable browser prototype with a shared Node.js + WebSocket backend.
It includes room creation/joining, two-player state sync, an island arena, mobile joystick,
third-person camera, health, an abstract arcade "TAG" action, and win/lose state.

## Important prototype limits
- This is an early playable prototype, not a production Free Fire clone.
- The TAG action is an abstract arcade hit mechanic, not realistic weapon simulation.
- Player state is synchronized through one server. For a public release, add authentication,
  rate limiting, server-side movement validation, anti-cheat, persistent accounts, and scaling.
- The server uses in-memory rooms. Restarting the server clears rooms.
- Both players must open the same deployed URL. A locally running server on one phone is not
  automatically reachable from another phone over the internet.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run:
   ```bash
   npm install
   npm start
   ```
3. Open `http://localhost:3000`.
4. For two-device testing on the same Wi-Fi, open `http://YOUR_COMPUTER_LAN_IP:3000`
   on both devices. Allow the port through your computer firewall if needed.

## Deploy the shared backend (Render example)
1. Upload this project to a GitHub repository.
2. In Render, create a **New Web Service** and connect that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Deploy. Render supplies an HTTPS URL.
6. Open that exact URL on both phones. The browser client automatically uses secure WebSocket
   (`wss://`) when served over HTTPS.
7. Player 1 selects CREATE ROOM and shares the six-character Room ID.
8. Player 2 enters the same Room ID and selects JOIN.

## Controls
- Left joystick: move.
- Drag on the open game view: rotate camera.
- TAG: send a server-validated arcade hit if the opponent is within range.
- JUMP: short visual hop.

## Project structure
- `server.js` — shared authoritative room server.
- `public/index.html` — game UI.
- `public/style.css` — mobile-first interface.
- `public/game.js` — Three.js island and client controls.

## Troubleshooting
- If the room cannot be joined, confirm both devices use the exact same deployed URL.
- If connection says disconnected, check the Render service is running and refresh both clients.
- If the room is full, create a new room.
